# Spring Boot H2 Database CRUD example: Building Rest API with Spring Data JPA

## Run Spring Boot application
```
mvn spring-boot:run
```

## Cambios