#!/bin/bash
echo "Soy un script, aviso, ChatGPT os va a quitar el trabajo."